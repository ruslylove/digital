# VHDL source code accompanying the textbook

**Digital Circuits and Microprocessor Fundamentals** — *From Boolean Algebra to Basic General-Purpose Microprocessors with VHDL*
Dr. Ruslee Sutthaweekul, KMUTNB (courses 010113025 and 010153101)

This archive contains every VHDL file printed in the book and the complete projects behind the larger examples.

## Contents

| Folder | What it is | Book chapter |
|---|---|---|
| `examples/` | the short stand-alone examples of Chapters 5–9 (one entity per file, named `chNN_*.vhd`) | 5–9 |
| `adders/` | half/full adder, 4-bit ripple-carry adder, adder–subtractor, carry-look-ahead adders (4-bit and 16-bit), 4×4 multiplier, with test benches | 2, 4 |
| `parity/` | parity generator, parity checker and a test bench | 3 |
| `spi_packet_detector/` | extra lecture example: SPI packet detector (edge detector, FSM, output modulator) | — |
| `if_then_else/` | the if-then-else algorithm as a processor: datapath, control unit (with and without the extra wait state), top level, test bench | 9 |
| `gcd/` | GCD processor: components package, datapath, control unit (FSM), top level, test bench | 9, App. C |
| `gcd_fsmd/` | the same GCD calculator written as a single FSMD, with test bench | 9 |
| `ec1/` | EC-1 microprocessor (16-word ROM program) with test bench and the ROM initialisation file `rom_data_1.hex` | 10, App. C |
| `ec2/` | EC-2 microprocessor (32 × 8 RAM, ADD/SUB/JZ/JPOS …) with test bench | 10, App. C |

## How to compile and simulate

Each project folder is **self-contained**: compile the files of *one* folder only. Several projects define their own `d_ff` entity (and `ec1`/`ec2` have their own component packages), so files of different folders must not be mixed in one library.

Files must be analysed in dependency order. The order below was derived from the `component` / `entity work.` references; test benches come last.

* **`adders/`** — `half_adder.vhd` → `cla_group_logic.vhd` → `pg_unit.vhd` → `sum_logic.vhd` → `cla_logic.vhd` → `full_adder.vhd` → `cla_4bit_block.vhd` → `cla_4bit_adder.vhd` → `ripple_adder_4bit.vhd` → `multiplier_4x4.vhd` → `cla_16bit_adder.vhd` → `ripple_adder_4bit_tb.vhd` → `adder_subtractor_4bit.vhd` → `multiplier_4x4_tb.vhd` → `tb_cla_16bit_adder.vhd` → `adder_subtractor_4bit_tb.vhd`
* **`parity/`** — `parity_generator.vhd` → `parity_checker.vhd` → `parity_system_tb.vhd`
* **`spi_packet_detector/`** — `d_ff.vhd` → `sclk_edge_detector.vhd` → `main_fsm.vhd` → `output_modulator.vhd` → `spi_packet_detector.vhd` → `spi_packet_detector_tb.vhd`
* **`if_then_else/`** — `control_unit_extra.vhd` → `datapath.vhd` → `control_unit.vhd` → `top.vhd` → `Algorithm_TB.vhd`
* **`gcd/`** — `gcd_control.vhd` → `components.vhd` → `gcd_datapath.vhd` → `gcd_top.vhd` → `gcd_tb.vhd`
* **`gcd_fsmd/`** — `gcd_fsmd.vhd` → `gcd_fsmd_tb.vhd`
* **`ec1/`** — `ec1_components.vhd` → `ec1_datapath.vhd` → `ec1_control_unit.vhd` → `ec1.vhd` → `ec1_tb.vhd`
* **`ec2/`** — `EC2_Components.vhd` → `EC2_Control_Unit.vhd` → `EC2_Datapath.vhd` → `ec2.vhd` → `ec2_tb.vhd`

Top-level entities: `ripple_adder_4bit`, `adder_subtractor_4bit`, `cla_16bit_adder`, `multiplier_4x4` (adders); `gcd_top` (gcd); `gcd_fsmd`; `ec1`; `ec2`. Test benches are the files ending in `_tb` (or starting with `tb_`); `Algorithm_TB.vhd` is the test bench of `if_then_else/`.

### GHDL (free, command line)

```bash
cd ec1
ghdl -a --std=08 ec1_components.vhd ec1_datapath.vhd ec1_control_unit.vhd ec1.vhd ec1_tb.vhd
ghdl -e --std=08 ec1_tb
ghdl -r --std=08 ec1_tb --wave=ec1.ghw --stop-time=2us     # view ec1.ghw with GTKWave
```

### ModelSim / Questa (Intel FPGA Starter Edition)

```tcl
vlib work
vcom -2008 ec1_components.vhd ec1_datapath.vhd ec1_control_unit.vhd ec1.vhd ec1_tb.vhd
vsim work.ec1_tb
add wave -r *
run 2 us
```

### Quartus Prime

Create a project in the folder, add the design files (not the test bench), set the top-level entity, compile and program the board. In `ec1/`, `rom_data_1.hex` is the Intel HEX initialisation file of the program ROM (see *Intel HEX format* in Chapter 10).

## Notes

* `examples/ch06_async_reset.vhd` and `examples/ch06_sync_reset.vhd` are **process fragments** (they show only the reset style, as in the book), not complete entities.
* `ch05_mux_4to1_behav.vhd` / `_struct.vhd` and `ch05_magnitude_comparator_behav.vhd` / `_struct.vhd` are two architectures (behavioural and structural) of the *same* entity: compile one of each pair, not both.
* `examples/ch09_if_then_else_control.vhd` instantiates `d_ff_r`, which is defined in `examples/ch06_seq_detector_struct.vhd`; compile that file first.
* The files in `examples/` are the versions printed in the book; they were corrected while the book was written (for instance the `d_ff_r` reset port and the output table of the if-then-else control unit). The project folders are the course sources.
* **Not simulated while preparing this archive:** no VHDL simulator was available, so the files were checked by reading, not by running them. Please report any compile error.

## Listing index (book listing → file)

| Listing | Description | File |
|---|---|---|
| 4.2 | Structural VHDL of a 4-bit ripple-carry adder. | `adders/ripple_adder_4bit.vhd` |
| 4.3 | VHDL of the 4-bit adder/subtractor, reusing the ripple-carry adder. | `adders/adder_subtractor_4bit.vhd` |
| 4.4 | Carry-lookahead logic block of the 4-bit CLA. | `adders/cla_logic.vhd` |
| 4.5 | Top level of the 4-bit carry-lookahead adder. | `adders/cla_4bit_adder.vhd` |
| 5.1 | VHDL of the BCD to excess-3 converter. | `examples/ch05_bcd_to_excess3.vhd` |
| 5.2 | Behavioural VHDL of a one-digit BCD adder. The package `numeric_std` provides the type `unsigned` and arithmetic on it. | `examples/ch05_bcd_adder.vhd` |
| 5.3 | A 3-to-8 decoder in VHDL. | `examples/ch05_decoder_3to8.vhd` |
| 5.4 | 4-to-1 multiplexer, behavioural architecture. | `examples/ch05_mux_4to1_behav.vhd` |
| 5.5 | 4-to-1 multiplexer written as a Boolean expression ("structural" in the lecture notes). | `examples/ch05_mux_4to1_struct.vhd` |
| 5.6 | A three-state buffer. | `examples/ch05_tri_state_buffer.vhd` |
| 5.7 | Behavioural description of the comparator using the relational operators. | `examples/ch05_magnitude_comparator_behav.vhd` |
| 5.8 | Gate-level description of the comparator. | `examples/ch05_magnitude_comparator_struct.vhd` |
| 6.1 | A D latch. The process is sensitive to both `D` and `C`; since no value is assigned when `C` is 0, the synthesis tool infers a latch. | `examples/ch06_d_latch.vhd` |
| 6.2 | A positive-edge-triggered D flip-flop. | `examples/ch06_d_ff.vhd` |
| 6.3 | A JK flip-flop. The internal signal `q_int` lets the value of `Q` be read back for the toggle operation. | `examples/ch06_jk_ff.vhd` |
| 6.4 | A T flip-flop. | `examples/ch06_t_ff.vhd` |
| 6.5 | Process with asynchronous reset. | `examples/ch06_async_reset.vhd` |
| 6.6 | Process with synchronous reset. | `examples/ch06_sync_reset.vhd` |
| 6.7 | The 101 detector as a state machine with an enumerated state type. | `examples/ch06_seq_detector_fsm.vhd` |
| 6.8 | The 101 detector as two D flip-flops and gates (structural description). | `examples/ch06_seq_detector_struct.vhd` |
| 7.1 | Behavioural VHDL of a 4-bit universal shift register with asynchronous clear. | `examples/ch07_universal_shift_register.vhd` |
| 7.2 | VHDL of a 4-bit counter with asynchronous clear, parallel load and count enable. | `examples/ch07_counter_parallel_load.vhd` |
| 8.1 | VHDL of the car security controller: an enumerated state type, a state-register process and a combinational process (the two-process method). | `examples/ch08_car_security.vhd` |
| 8.2 | Behavioural VHDL of the modulo-6 counter with enable. | `examples/ch08_modulo6_behav.vhd` |
| 8.3 | VHDL of the Mealy one-shot. | `examples/ch08_oneshot_mealy.vhd` |
| 8.4 | VHDL of the Moore one-shot (exact one-cycle pulse). | `examples/ch08_oneshot_moore.vhd` |
| 8.5 | VHDL of the Moore elevator controller (four states). | `examples/ch08_elevator_moore.vhd` |
| 8.6 | VHDL of the Mealy elevator controller (two states). | `examples/ch08_elevator_mealy.vhd` |
| 9.1 | Structural VHDL of the if-then-else control unit (state register of D flip-flops and the synthesised equations). The component `d_ff_r` is the flip-flop with asynchronous reset of Listing 6.8. | `examples/ch09_if_then_else_control.vhd` |
| 9.2 | VHDL of the GCD control unit (FSM with five states). | `gcd/gcd_control.vhd` |
| 9.3 | The GCD calculator as an FSMD: datapath operations inside a single behavioural state machine. | `gcd_fsmd/gcd_fsmd.vhd` |
| 10.1 | VHDL of the EC-1 control unit (structural, from the state equations). | `ec1/ec1_control_unit.vhd` |
| 10.2 | VHDL of the EC-1 datapath. | `ec1/ec1_datapath.vhd` |
| C.1 | GCD processor: library of components (registers, multiplexers, subtractor, comparator, dots). | `gcd/components.vhd` |
| C.2 | GCD processor: datapath. | `gcd/gcd_datapath.vhd` |
| C.3 | GCD processor: top level connecting control unit and datapath. | `gcd/gcd_top.vhd` |
| C.4 | GCD processor: testbench. | `gcd/gcd_tb.vhd` |
| C.5 | EC-1: components package. | `ec1/ec1_components.vhd` |
| C.6 | EC-1: top level. | `ec1/ec1.vhd` |
| C.7 | EC-1: testbench (input value 10). | `ec1/ec1_tb.vhd` |
| C.8 | EC-2: control unit. | `ec2/EC2_Control_Unit.vhd` |
| C.9 | EC-2: datapath. | `ec2/EC2_Datapath.vhd` |
| C.10 | EC-2: components package, including the RAM whose initial contents are the GCD program of Table 10.6. | `ec2/EC2_Components.vhd` |
| C.11 | EC-2: top level. | `ec2/ec2.vhd` |
| C.12 | EC-2: testbench. | `ec2/ec2_tb.vhd` |

Free to use for teaching and study; please keep the author's name when redistributing.
